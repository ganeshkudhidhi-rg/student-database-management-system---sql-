-- Student Database Management System

CREATE TABLE Students (
    student_id INT PRIMARY KEY,
    student_name VARCHAR(100),
    gender VARCHAR(10),
    department VARCHAR(50)
);

CREATE TABLE Courses (
    course_id INT PRIMARY KEY,
    course_name VARCHAR(100)
);

CREATE TABLE Marks (
    mark_id INT PRIMARY KEY,
    student_id INT,
    course_id INT,
    marks INT,
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id)
);

INSERT INTO Students VALUES
(1,'Rahul','Male','BCom'),
(2,'Priya','Female','BCom'),
(3,'Arjun','Male','BBA');

INSERT INTO Courses VALUES
(101,'SQL'),
(102,'Excel');

INSERT INTO Marks VALUES
(1,1,101,85),
(2,2,101,92),
(3,3,102,78);

-- View all students
SELECT * FROM Students;

-- Students scoring above 80
SELECT student_name, marks
FROM Students
JOIN Marks USING(student_id)
WHERE marks > 80;

-- Average marks by course
SELECT course_name, AVG(marks) AS average_marks
FROM Courses
JOIN Marks USING(course_id)
GROUP BY course_name;

-- Top scorer
SELECT student_name, marks
FROM Students
JOIN Marks USING(student_id)
ORDER BY marks DESC;
